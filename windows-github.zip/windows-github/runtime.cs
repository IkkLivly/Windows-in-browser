// A Hello World! program in C#.
using System;
namespace HelloWorld
{
    class Hello 
    {
        static void Main() 
        {
            Console.WriteLine("Hello World!");
        
        [SecurityCriticalAttribute]
public int Run(
	Window window
)
        
        
        }
    }
}